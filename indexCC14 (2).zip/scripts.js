document.addEventListener("DOMContentLoaded", function () {
    const hamburger = document.querySelector(".hamburger");
    const navLinks = document.querySelector(".nav-links");

    hamburger.addEventListener("click", function () {
        navLinks.classList.toggle("active");
    });
});
// Function to add "visible" class when scrolling
document.addEventListener("DOMContentLoaded", function () {
    const sections = document.querySelectorAll(".section");

    function revealSections() {
        sections.forEach((section) => {
            const sectionTop = section.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;

            if (sectionTop < windowHeight - 100) {
                section.classList.add("visible");
            }
        });
    }

    window.addEventListener("scroll", revealSections);
    revealSections(); // Run on page load
});
// Function to apply parallax effect
document.addEventListener("scroll", function () {
    const scrollTop = window.scrollY;
    document.querySelectorAll(".parallax-element").forEach((el) => {
        el.style.transform = `translateY(${scrollTop * 0.3}px)`;
    });
});

